<!DOCTYPE html SYSTEM "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <title>SaxonC PHPInfo</title>
    </head>
    <body>
        <?php phpinfo(); ?>
    </body>
</html>
